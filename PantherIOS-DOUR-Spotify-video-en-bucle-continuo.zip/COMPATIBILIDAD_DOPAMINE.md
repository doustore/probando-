# Panther iOS — edición con comprobación de versión

- Basado en Panther-iOS-Final-actualizado.zip.
- Se muestra un aviso y se bloquea la interfaz en iOS 17 o posterior, incluido iOS 26.0.1.
- Se permite acceder a la interfaz en iOS 15 y 16, **sin afirmar que Dopamine esté instalado o sea compatible con cada combinación de dispositivo y versión**.
- No se ha implementado modificación automática de archivos de Free Fire.
- Se conservan los archivos y las funciones locales del proyecto; el acceso ya no depende de un servidor de licencias.
- **No se ha compilado ni probado en un dispositivo físico**. El proyecto requiere validación con Xcode y un dispositivo compatible.

# Cuello.3105

El archivo `Cuello.3105` está incluido como recurso en el proyecto y aparece en la lista de Patches.

El archivo contiene un contenedor `3105PATCH` con plist binario y payload cifrado. No se ha descifrado ni ejecutado; mostrarlo no significa que esté aplicado. La aplicación necesitaría su mecanismo original de importación/validación y una acción explícita para aplicarlo de forma compatible.

Los patches locales se administran desde la biblioteca integrada de la aplicación; ya no se requiere autenticación de licencias para acceder a la pantalla.

import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @State private var launchStage = 0 // 0 = Spotify splash, 1 = DOUR entry, 2 = app
    @State private var accessText = ""
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = AppSection.patches.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if launchStage == 0 {
                SpotifySplashView()
            } else if launchStage == 1 {
                DOURWelcomeView(accessText: $accessText) {
                    // El acceso es directo: no se consulta ni valida ninguna key.
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 2 }
                }
            } else {
                PatchProjectsView(ghostTheme: true)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(true)
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onAppear {
            guard launchStage == 0 else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.35) {
                withAnimation(.easeInOut(duration: 0.35)) { launchStage = 1 }
            }
        }
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView(ghostTheme: true)
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .patches
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    var body: some View {
        NavigationStack {
            List {
                deviceSection
                featuresSection
            }
            .navigationBarTitleDisplayMode(.inline)
            .tint(AppTheme.accent)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "apple.terminal")
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Link(destination: URL(string: "https://t.me/+6L89Qcso3w9kN2Yx")!) {
                        Image(systemName: "paperplane.fill")
                            .foregroundStyle(.cyan)
                    }
                    .accessibilityLabel("Abrir grupo de Telegram")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var featuresSection: some View {
        Section {
            Toggle(isOn: $cleanerEnabled) {
                Label(language.text("tab.cleaner"), systemImage: "sparkles")
            }
            if wallpapersSupported {
                Toggle(isOn: $wallpapersEnabled) {
                    Label(language.text("tab.wallpapers"), systemImage: "photo.on.rectangle.angled")
                }
            }
        } header: {
            Text(language.text("dashboard.features"))
        } footer: {
            Text(language.text("dashboard.features_footer"))
        }
    }

    private var deviceSection: some View {
        Section {
            LabeledContent(language.text("dashboard.hardware_model")) {
                Text(AppInfo.displayMachineName)
                    .font(.body.monospaced())
            }
            LabeledContent(language.text("settings.ios_version")) {
                Text("\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    .font(.body.monospaced())
            }
            HStack {
                Text(language.text("settings.compatibility"))
                Spacer()
                Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            if appState.kernelExploitApplicable && AppInfo.versionTuple.major < 26 {
                HStack {
                    Text(language.text("dashboard.kernel_status"))
                    Spacer()
                    if appState.kernelExploitRunning {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text(language.text("dashboard.kernel_running"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Text(language.text(appState.exploitStatus.isSuccess ? "dashboard.kernel_active" : "dashboard.kernel_inactive"))
                        .foregroundStyle(appState.exploitStatus.isSuccess ? Color.green : Color.secondary)
                    }
                }
            }
        } header: {
            Text(language.text("common.device"))
        } footer: {
            Text(language.text("settings.supported_range_summary"))
        }
    }
}


// MARK: - DOUR / Spotify entry experience

private struct SpotifySplashView: View {
    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.035, blue: 0.035).ignoresSafeArea()
            SpotifyRoundMark()
                .frame(width: 150, height: 150)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

private struct DOURWelcomeView: View {
    @Binding var accessText: String
    let onContinue: () -> Void

    var body: some View {
        ZStack {
            // Use the original green-and-black video as the only screen background.
            DOURLoopingVideoBackground()
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer(minLength: 26)

                SpotifyRoundMark()
                    .frame(width: 76, height: 76)
                    .padding(.bottom, 20)

                Text("DOUR")
                    .font(.system(size: 47, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(Color(red: 0.16, green: 0.88, blue: 0.43))

                Text("EXTENAL SPOTIFY")
                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white.opacity(0.68))
                    .padding(.top, 7)

                Text("External Spotify")
                    .font(.system(size: 27, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .padding(.top, 40)

                TextField("", text: $accessText, prompt:
                    Text("Ingrese su key").foregroundColor(.white.opacity(0.38))
                )
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(.white)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(.horizontal, 22)
                .frame(height: 68)
                .background(Color.black.opacity(0.78))
                .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.13), lineWidth: 1))
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .padding(.bottom, 18)

                Button(action: onContinue) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 22)
                            .fill(Color(red: 0.10, green: 0.72, blue: 0.34))
                        DOURCheckerboard()
                            .clipShape(RoundedRectangle(cornerRadius: 22))
                            .opacity(0.25)
                        Text("CONTINUAR")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .tracking(2)
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.35), radius: 3, y: 1)
                    }
                    .frame(height: 70)
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.green.opacity(0.55), lineWidth: 1))
                }
                .buttonStyle(.plain)

                Link(destination: URL(string: "https://t.me/Jxsuesinho")!) {
                    HStack(spacing: 9) {
                        Image(systemName: "paperplane.fill")
                        Text("CONTACTO")
                            .font(.system(size: 14, weight: .heavy, design: .rounded))
                            .tracking(2)
                    }
                    .foregroundStyle(Color(red: 0.22, green: 0.92, blue: 0.48))
                    .padding(.vertical, 16)
                    .padding(.horizontal, 26)
                    .background(Color.black.opacity(0.65))
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(Color.green.opacity(0.45), lineWidth: 1))
                }
                .padding(.top, 20)

                Spacer(minLength: 28)
            }
            .padding(.horizontal, 30)
            .frame(maxWidth: 520)
        }
    }
}


private struct DOURLoopingVideoBackground: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlayerContainerView {
        let view = PlayerContainerView()
        guard let url = Bundle.main.url(forResource: "DOURKeyBackground", withExtension: "mp4") else {
            return view
        }

        let item = AVPlayerItem(url: url)
        let player = context.coordinator.player
        player.replaceCurrentItem(with: item)
        player.isMuted = true
        player.actionAtItemEnd = .none

        // Restart from the beginning every time the clip reaches its end.
        context.coordinator.endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak player] _ in
            guard let player = player else { return }
            player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero) { finished in
                if finished {
                    player.play()
                }
            }
        }

        view.playerLayer.player = player
        view.playerLayer.videoGravity = .resizeAspectFill
        player.play()
        return view
    }

    func updateUIView(_ uiView: PlayerContainerView, context: Context) {
        let player = context.coordinator.player
        if player.currentItem != nil && player.timeControlStatus != .playing {
            player.play()
        }
    }

    static func dismantleUIView(_ uiView: PlayerContainerView, coordinator: Coordinator) {
        coordinator.player.pause()
        uiView.playerLayer.player = nil
        if let observer = coordinator.endObserver {
            NotificationCenter.default.removeObserver(observer)
            coordinator.endObserver = nil
        }
    }

    final class Coordinator {
        let player = AVPlayer()
        var endObserver: NSObjectProtocol?
    }
}

private final class PlayerContainerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

private struct SpotifyRoundMark: View {
    private let spotifyGreen = Color(red: 0.12, green: 0.84, blue: 0.39)

    var body: some View {
        GeometryReader { geometry in
            let side = min(geometry.size.width, geometry.size.height)
            ZStack {
                Circle().fill(spotifyGreen)
                SpotifyWave()
                    .stroke(Color.black, style: StrokeStyle(lineWidth: side * 0.085, lineCap: .round, lineJoin: .round))
                    .padding(side * 0.17)
            }
            .frame(width: side, height: side)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .accessibilityLabel("Spotify")
    }
}

private struct SpotifyWave: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        path.move(to: CGPoint(x: w * 0.05, y: h * 0.30))
        path.addQuadCurve(to: CGPoint(x: w * 0.95, y: h * 0.43),
                          control: CGPoint(x: w * 0.52, y: h * 0.10))
        path.move(to: CGPoint(x: w * 0.12, y: h * 0.52))
        path.addQuadCurve(to: CGPoint(x: w * 0.87, y: h * 0.62),
                          control: CGPoint(x: w * 0.52, y: h * 0.36))
        path.move(to: CGPoint(x: w * 0.20, y: h * 0.72))
        path.addQuadCurve(to: CGPoint(x: w * 0.78, y: h * 0.79),
                          control: CGPoint(x: w * 0.52, y: h * 0.61))
        return path
    }
}

private struct DOURCheckerboard: View {
    var body: some View {
        Canvas { context, size in
            let tile: CGFloat = 22
            let columns = Int(ceil(size.width / tile))
            let rows = Int(ceil(size.height / tile))
            for row in 0..<rows {
                for column in 0..<columns where (row + column).isMultiple(of: 2) {
                    let rect = CGRect(x: CGFloat(column) * tile, y: CGFloat(row) * tile,
                                      width: tile, height: tile)
                    context.fill(Path(rect), with: .color(Color(red: 0.05, green: 0.65, blue: 0.27)))
                }
            }
        }
    }
}
